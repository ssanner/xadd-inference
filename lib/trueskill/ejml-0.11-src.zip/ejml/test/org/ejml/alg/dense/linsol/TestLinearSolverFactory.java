package org.ejml.alg.dense.linsol;

import org.junit.Test;

import static org.junit.Assert.fail;


/**
 * @author Peter Abeles
 */
public class TestLinearSolverFactory {
    @Test
    public void stuff() {
        fail("implement");
    }
}
