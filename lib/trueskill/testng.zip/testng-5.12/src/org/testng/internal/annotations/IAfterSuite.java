package org.testng.internal.annotations;

public interface IAfterSuite extends IBaseBeforeAfter {

}
